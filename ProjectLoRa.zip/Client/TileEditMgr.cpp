#include "pch.h"
#include "TileEditMgr.h"


SINGLE_HEADER(TileEditMgr);


TileEditMgr::TileEditMgr()
{
}


TileEditMgr::~TileEditMgr()
{
}