#pragma once



class TileEditMgr
{
	SINGLE(TileEditMgr)

private:
	UINT	 mTileX;
	UINT	 mTileY;

public:
	UINT GetTileX() { return mTileX; }
	UINT GetTileY() { return mTileY; }

	void SetTileX(int x) { mTileX = (UINT)x; }
	void SetTileY(int y) { mTileY = (UINT)y; }
};

