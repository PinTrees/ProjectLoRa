#include "pch.h"
#include "AI.h"

#include "CState.h"
#include "IdleState.h"
#include "TraceState.h"


//template class AI<MONSTER_STATE>;
//template class AI<PLAYER_STATE>;

