#pragma once

class CRandom
{
	SINGLE(CRandom)
private:



public:
	void Init();

	int Next(int start, int end);


};