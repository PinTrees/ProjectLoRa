<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Tiles" tilewidth="32" tileheight="32" tilecount="81" columns="9">
 <image source="../../Tiles.png" trans="ff00ff" width="288" height="288"/>
</tileset>
